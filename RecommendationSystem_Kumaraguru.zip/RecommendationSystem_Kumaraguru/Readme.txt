1) SentimentBasedRecommendationSystem_FINAL.ipynb - The file where all EDA, cleaning, model building, evaluation, decision making is done. All the 7 Steps of the evaluation rubric can be seen here.
2) model.ipynb - Consolidated code for SentimentBasedRecommendationSystem_FINAL.ipynb where the essentials are placed, models are pickled. 
3) recommendation_heroku - The project where app.py is the backend server with the pickled models are unzipped and loaded for serving client requests. templates\index.html is the file that serves as the view.
4) Task 8's outcome - https://kumarthegururecommender.herokuapp.com/ - The Heroku public application where the recommendation system is deployed. If you are not able to load is for whatever reason, call me on +919880292215.
