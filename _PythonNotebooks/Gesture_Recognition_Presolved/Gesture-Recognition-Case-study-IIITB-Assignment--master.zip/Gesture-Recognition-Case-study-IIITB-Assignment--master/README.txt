#############################################################################

PG Diploma in Machine Learning and AI from IIIT Bangalore | Upgrad

Developed by:
1. Deepa Kushwaha - Group facilitator
2. Prateek Ralhan

******** COHORT 11 *************

#############################################################################

Solution - NEURAL NETWORKS PROJECT - GESTURE RECOGNITION - DL

#############################################################################

1. Create a virtual environment and navigate to the folder where you have
unzipped the contents of this zip file.

2. You can install the dependencies using : "pip install -r requirements.txt".
These are the dependencies supported by the "NimbleBox.ai" platform which we
used for defining, training and validating our model (the 'requirement.txt'
has been sourced out from there using it's terminal in order to ensure smooth 
execution of the jupyter code. )

3.  Run command "Jupyter notebook" to open the jupyter dashboard and now you can
skim across the Jupyter code (.ipynb file) / execute it.

#############################################################################
